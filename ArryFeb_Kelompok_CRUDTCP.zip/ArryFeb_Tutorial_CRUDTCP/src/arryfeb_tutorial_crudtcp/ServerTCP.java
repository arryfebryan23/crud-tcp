package arryfeb_tutorial_crudtcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author ArryFebryan
 */
public class ServerTCP {
    
    public static void main(String args[]) throws IOException{
        System.out.print(""
                + "==========================================================\n"
                + "\t\tTCP Server - Arry Febryan\n"
                + "==========================================================\n");
        
        //Membuat jalur komunikasi
        ServerSocket serverSocket = null;
        int port = 8000;
       
        try{
            serverSocket = new ServerSocket(port);
            System.out.println("[TCP server] Jalur komunikasi berhasil dibuat di port = "+port);            
        }catch(IOException e){
            System.out.println("Error: Server tidak dapat membuat port = "+port);
        }
        
        
        while(true){
            Socket clientSocket = null;

            //Menunggu request client
            try {
                System.out.println("\n[TCP Server] Menunggu permintaan dari client ...");
                clientSocket = serverSocket.accept();
            } catch (IOException e) {
                System.out.println("Error: Tidak dapat menerima permintaan client.. Keluar Program");
                return;
            }
            
            //Memproses permintaan client
            try {
                processClientRequest(clientSocket);
            } catch (IOException e) {
                System.out.println("Error: Tidak dapat menerima permintaan client..");               
            }       
        }
    }
    
    //Method untuk memproses data yang dikirim oleh client
    public static void processClientRequest(Socket clientSocket) throws IOException {
        System.out.println("[TCP Server] Memproses permintaan yang masuk..");
        try {
            OutputStream output = clientSocket.getOutputStream();
            InputStream input = clientSocket.getInputStream();
            
            PrintStream printStream = new PrintStream(output);
            InputStreamReader inputStream = new InputStreamReader(input);
 
            BufferedReader bufferedReader = new BufferedReader(inputStream);
            
            String message = null;
            message = bufferedReader.readLine();
            System.out.println(" Permintaan telah diterima : "+message);
            
            /////Message incoming
            try{
                String sql = message;
                java.sql.Connection conn=(Connection)Config.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                
                System.out.println("\tPermintaan berhasil diproses..");
                
                String messageSend = "Permintaan berhasil diproses";
                printStream.println(messageSend);
                
            }catch(SQLException e){
                System.out.println("\tError: Permintaan tidak dapat diproses..");  
                
                String messageSend = "Permintaan tidak dapat diproses";
                printStream.println(messageSend);
            }
            
           
            printStream.close(); //menutup jalur komunikasi
            
        }catch (Exception e){
            System.out.print("[TCP Server] The server cannot send the message");
        }
    }
}

